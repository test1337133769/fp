// simplified placeholder; replace with full canvas version
export default function Home(){return <div>Donation Site</div>}